// clob.js
const GAMMA = 'https://gamma-api.polymarket.com';
const CLOB = 'https://clob.polymarket.com';

function parseBins(eventArr) {
  const ev = eventArr && eventArr[0];
  if (!ev || !ev.markets) return [];
  const bins = ev.markets.flatMap(m => {
    // 只保留仍可下注的 bin：已结算 / 已淘汰 / 未激活的过滤掉
    if (m.acceptingOrders === false || m.closed === true || m.active === false) return [];
    try {
      const tokens = JSON.parse(m.clobTokenIds);
      // 排序用价：优先 bestAsk（网页显示的买入价/概率）；为 0 / null / 缺失（无卖单）时回退 outcomePrices
      // 注意 Number(null)===0，必须用 >0 判断而非 isFinite，否则无卖单的冷门候选会被当成 0 排到最后
      let price = Number(m.bestAsk);
      if (!(price > 0)) {
        try { price = Number(JSON.parse(m.outcomePrices)[0]) || 0; } catch { price = 0; }
      }
      return [{
        title: m.groupItemTitle || m.question,
        yesToken: tokens[0], noToken: tokens[1],
        price, threshold: Number(m.groupItemThreshold),
      }];
    } catch { return []; }
  });
  // 还原网页显示顺序（通用，不针对单一市场）：
  //  - sortBy='price'（概率竞争类，如候选人/球队）→ 按概率降序
  //  - 否则有完整 groupItemThreshold（有序选项类，如温度/利率档位）→ 按 threshold 升序
  //  - 都不满足 → 保持 gamma 原序
  if (ev.sortBy === 'price') {
    // price 降序为主键；price 并列（如各选项概率都极低）时按 groupItemThreshold 升序打破并列
    bins.sort((a, b) => (b.price - a.price) || (a.threshold - b.threshold) || 0);
  } else if (bins.every(b => Number.isFinite(b.threshold))) {
    bins.sort((a, b) => a.threshold - b.threshold);
  }
  return bins;
}

async function fetchEventBins(slug) {
  const r = await fetch(`${GAMMA}/events?slug=${encodeURIComponent(slug)}`);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return parseBins(await r.json());
}

async function fetchBook(tokenId) {
  const r = await fetch(`${CLOB}/book?token_id=${tokenId}`);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}

// 从 URL 路径取 event slug，兼容非英文语言前缀（/it/event/x、/zh/event/x、/zh-hant/event/x）；非 event 页返回 null
function eventSlugFromPath(pathname) {
  const p = (pathname || '').split('/').filter(Boolean);
  const i = p.indexOf('event');
  return (i !== -1 && p[i + 1]) ? p[i + 1] : null;
}

if (typeof module !== 'undefined') module.exports = { parseBins, fetchEventBins, fetchBook, eventSlugFromPath };
